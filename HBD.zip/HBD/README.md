# Happy 21st Birthday Website 🎂

This is a cute and adorable birthday website created for a special 21st birthday celebration!

## How to use

**(No installation required!)**

1.  Simply open `index.html` in any web browser (Double click it!).
2.  That's it!

## Customization

-   **Music**: Add an MP3 file to the `assets/` folder and update `script.js` to play it.
-   **Photos**: Replace the placeholders in `index.html` with real `<img>` tags pointing to her photos.
-   **Message**: Edit the text in `index.html` to personalize the wish further.

## Hosting for Free

Since this is just HTML, CSS, and JS, you can host it for free easily on:
-   **GitHub Pages**: Upload these files to a repo and enable Pages.
-   **Netlify / Vercel**: Drag and drop this folder.
-   **Surge.sh**: Simple command line deployment.

Enjoy! ❤️
